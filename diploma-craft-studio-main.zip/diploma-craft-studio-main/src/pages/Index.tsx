import DiplomaBuilder from "@/components/DiplomaBuilder";

const Index = () => {
  return <DiplomaBuilder />;
};

export default Index;
